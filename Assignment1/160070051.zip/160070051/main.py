import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as ss
from tqdm import tqdm
from base import *

iterations = 20
T = 10**5
delta = 0.1

wm_regret = []
exp3_regret = []
exp3p_regret = []
exp3ix_regret = []

print("Calculating wm_regret")
for c in tqdm(np.arange(0.1,2.15,0.2)):
    R_i = []
    eta = c * np.sqrt(2*np.log(10)/T)
    R_i.append(eta)
    for itr in tqdm(range(iterations)):
        env = Environment(delta, T, 'full_info')
        R_i.append(WeightedMajority(env,eta))
    wm_regret.append(R_i)

iterations = 50

print("\n\nCalculating exp3_regret")
for c in tqdm(np.arange(0.1,2.15,0.2)):
    R_i = []
    eta = c * np.sqrt(2*np.log(10)/T)
    R_i.append(eta)
    for itr in tqdm(range(iterations)):
        env = Environment(delta, T, 'full_info')
        R_i.append(exp3_algorithm(env,eta))
    exp3_regret.append(R_i)

print("\n\nCalculating exp3p_regret")
for c in tqdm(np.arange(0.1,2.15,0.2)):
    R_i = []
    eta = c * np.sqrt(2*np.log(10)/T)
    R_i.append(eta)
    for itr in tqdm(range(iterations)):
        env = Environment(delta, T, 'full_info')
        R_i.append(exp3P_algorithm(env,eta,eta,10*eta))
    exp3p_regret.append(R_i)

print("\n\nCalculating exp3ix_regret")
for c in tqdm(np.arange(0.1,2.15,0.2)):
    R_i = []
    eta = c * np.sqrt(2*np.log(10)/T)
    R_i.append(eta)
    for itr in tqdm(range(iterations)):
        env = Environment(delta, T, 'full_info')
        R_i.append(exp3IX_algorithm(env,eta,eta/2))
    exp3ix_regret.append(R_i)

print("\n\n")
# Regret Data
# exp3_regret = [[R_1], ..., [R_i], ..., [R_C]]
# where [R_i] - [etaValue_i, regretSamplePath_i1, ..., regretSamplePath_iN]
# where 'N' is number of sample paths and 'C' is the total number of values that 'c' can take.
# exp3_regret = [[], []]  # = [[...], ..., [etaValue_i, regretSamplePath_i1, ..., regretSamplePath_iC], ..., [...]]
# exp3p_regret = [[], []]
# exp3ix_regret = [[], []]


# Plotting Regret vs Eta
# EXP3
eta = []
regret_mean = []
regret_err = []
freedom_degree = len(exp3_regret[0]) - 2
for regret in exp3_regret:
    eta.append(regret[0])
    regret_mean.append(np.mean(regret[1:]))
    regret_err.append(ss.t.ppf(0.95, freedom_degree) * ss.sem(regret[1:]))

colors = list("rgbcmyk")
shape = ['--^', '--d', '--v']
plt.errorbar(eta, regret_mean, regret_err, color=colors[0])
plt.plot(eta, regret_mean, colors[0] + shape[0], label='EXP3')


# EXP3.P
eta = []
regret_mean = []
regret_err = []
freedom_degree = len(exp3p_regret[0]) - 2
for regret in exp3p_regret:
    eta.append(regret[0])
    regret_mean.append(np.mean(regret[1:]))
    regret_err.append(ss.t.ppf(0.95, freedom_degree) * ss.sem(regret[1:]))

plt.errorbar(eta, regret_mean, regret_err, color=colors[1])
plt.plot(eta, regret_mean, colors[1] + shape[1], label='EXP3.P')


# EXP3-IX
eta = []
regret_mean = []
regret_err = []
freedom_degree = len(exp3ix_regret[0]) - 2
for regret in exp3ix_regret:
    eta.append(regret[0])
    regret_mean.append(np.mean(regret[1:]))
    regret_err.append(ss.t.ppf(0.95, freedom_degree) * ss.sem(regret[1:]))

plt.errorbar(eta, regret_mean, regret_err, color=colors[2])
plt.plot(eta, regret_mean, colors[2] + shape[2], label='EXP3-IX')


# Plotting
plt.legend(loc='upper right', numpoints=1)
plt.title("Pseudo Regret vs Learning Rate for T = 10^4 and 50 Sample paths")
plt.xlabel("Learning Rate")
plt.ylabel("Pseudo Regret")
plt.savefig("Q2.png", bbox_inches='tight')
plt.close()

#-------------------------------------------------------------------------------
# Weighted Majority
eta = []
regret_mean = []
regret_err = []
freedom_degree = len(wm_regret[0]) - 2
for regret in wm_regret:
    eta.append(regret[0])
    regret_mean.append(np.mean(regret[1:]))
    regret_err.append(ss.t.ppf(0.95, freedom_degree) * ss.sem(regret[1:]))

colors = list("rgbcmyk")
shape = ['--^', '--d', '--v']
plt.errorbar(eta, regret_mean, regret_err, color=colors[0])
plt.plot(eta, regret_mean, colors[3] + shape[0], label='WM')

# Plotting
plt.legend(loc='upper right', numpoints=1)
plt.title("Pseudo Regret vs Learning Rate for T = 10^4 and 20 Sample paths")
plt.xlabel("Learning Rate")
plt.ylabel("Pseudo Regret")
plt.savefig("Q1.png", bbox_inches='tight')
plt.close()
