import scipy
import scipy.stats as ss
import matplotlib.pyplot as plt
from tqdm import tqdm
import numpy as np
from numpy import exp

# Note that in this program the arms are numbered [0 to 1] and 'NOT' [1 to 2]

class Environment:
    def __init__(self, total_time):
        self.m_num_arms = 2
        self.m_total_time = total_time
        self.m_current_time = 0
        return

    def generate_loss(self, arm):
        if arm==0: # we are dealing with losses here and not rewards
            return 1 if self.m_current_time > (self.m_total_time)/4 else 0
        else:
            return 1 if self.m_current_time <= (self.m_total_time)/4 else 0

    def get_best_arm_loss(self):
        return (1-0.55)*self.m_total_time


def exp3_algorithm(envment_obj, eta, xti):
    #initialization
    alg_cummloss = 0
    est_cumm_losses = np.zeros(2,dtype=np.float128)

    for time in tqdm(range(1,envment_obj.m_total_time+1)):
        envment_obj.m_current_time = time
        prob_dist = (
            np.exp(-eta*est_cumm_losses)/sum(np.exp(-eta*est_cumm_losses))
                )
        arms = range(2)
        prob_rv = scipy.stats.rv_discrete(values=(arms,prob_dist))
        chosen_arm = prob_rv.rvs(size=1)
        loss = envment_obj.generate_loss(xti)
        alg_cummloss = alg_cummloss + loss
        est_cumm_losses[chosen_arm] = (est_cumm_losses[chosen_arm] +
            loss/prob_dist[chosen_arm])

    regret = alg_cummloss - envment_obj.get_best_arm_loss()
    return regret

if __name__ == "__main__":
    iterations = 20
    T = 10**5

    exp3_regret = []

    print("Calculating exp3_regret")
    for c in tqdm(np.arange(0.1,2.15,0.2)):
        R_i = []
        eta = c * np.sqrt(2*np.log(10)/T)
        R_i.append(eta)
        for itr in tqdm(range(iterations)):
            env = Environment(T)
            R_i.append(exp3_algorithm(env,eta,'xt1'))
        exp3_regret.append(R_i)

    print("\n\n")
    # Plotting Regret vs Eta
    # EXP3 (xt1 case)
    eta = []
    regret_mean = []
    regret_err = []
    freedom_degree = len(exp3_regret[0]) - 2
    for regret in exp3_regret:
        eta.append(regret[0])
        regret_mean.append(np.mean(regret[1:]))
        regret_err.append(ss.t.ppf(0.95, freedom_degree) * ss.sem(regret[1:]))

    colors = list("rgbcmyk")
    shape = ['--^', '--d', '--v']
    plt.errorbar(eta, regret_mean, regret_err, color=colors[0])
    plt.plot(eta, regret_mean, colors[0] + shape[0], label='EXP3')
    
    # Plotting
    plt.legend(loc='upper right', numpoints=1)
    plt.title("Pseudo Regret vs Learning Rate for T = 10^4 and 20 Sample paths")
    plt.xlabel("Learning Rate")
    plt.ylabel("Pseudo Regret")
    plt.savefig("Q7.png", bbox_inches='tight')
    plt.close()

