import scipy
from tqdm import tqdm
import numpy as np
from numpy import exp

# Note that in this program the arms are numbered [0 to 9] and 'NOT' [1 to 10]

class Environment:
    def __init__(self, delta, total_time, envment_type='full_info'):
        if envment_type != 'full_info' and envment_type != 'bandit':
            print("Wrong string given as evnment_type argument")
            raise SystemExit
        self.m_num_arms = 10
        self.m_delta = delta
        self.m_total_time = total_time
        self.m_current_time = 0
        if envment_type == 'full_info':
            self.m_cumm_losses_arms = np.zeros(10)
        return

    def generate_full_losses(self):
        losses = scipy.stats.bernoulli.rvs(size=8, p=0.5)
        losses = scipy.append(losses, scipy.stats.bernoulli.rvs(size=1,
            p=0.5-self.m_delta))
        if self.m_current_time <= (self.m_total_time)/2:
            losses = scipy.append(losses,
                scipy.stats.bernoulli.rvs(size=1,p=0.5+self.m_delta))
        else:
            assert self.m_current_time <= self.m_total_time
            losses = scipy.append(losses,
                scipy.stats.bernoulli.rvs(size=1,p=0.5-2*self.m_delta))
        return losses

    def generate_bandit_loss(self, arm_num):
        if arm_num < 8 and arm_num >= 0:
            return scipy.stats.bernoulli.rvs(size=1, p=0.5)
        elif arm_num == 8:
            return scipy.stats.bernoulli.rvs(size=1, p=0.5-self.m_delta)
        elif arm_num == 9:
            if self.m_current_time <= (self.m_total_time)/2:
                return scipy.stats.bernoulli.rvs(size=1, p=0.5+self.m_delta)
            else:
                assert self.m_current_time <= self.m_total_time
                return scipy.stats.bernoulli.rvs(size=1, p=0.5-2*self.m_delta)
        else:
            print("Error: Arm Number out of range")
            raise SystemExit

    def get_best_arm_loss(self):
        return (0.5-self.m_delta)*self.m_total_time

def WeightedMajority(envment_obj, eta):
    #initialization
    alg_cummloss = 0
    weights = np.ones(10,dtype=np.float128)

    for time in tqdm(range(1,envment_obj.m_total_time+1)):
        envment_obj.m_current_time = time
        weight_sum = np.sum(weights)
        norm_weights = weights/weight_sum
        arms = range(10)
        prob_rv = scipy.stats.rv_discrete(values=(arms,norm_weights))
        chosen_arm = prob_rv.rvs(size=1)
        full_losses = envment_obj.generate_full_losses()
        envment_obj.m_cumm_losses_arms = (envment_obj.m_cumm_losses_arms +
            full_losses)
        alg_cummloss = alg_cummloss + np.dot(weights, full_losses)
        weights = np.array([weights[idx]*exp(-1*eta*full_losses[idx]) for idx in
            range(len(weights))])
        assert len(weights) == 10

    regret = alg_cummloss - min(envment_obj.m_cumm_losses_arms)
    return regret

def exp3_algorithm(envment_obj, eta):
    #initialization
    alg_cummloss = 0
    est_cumm_losses = np.zeros(10,dtype=np.float128)

    for time in tqdm(range(1,envment_obj.m_total_time+1)):
        envment_obj.m_current_time = time
        prob_dist = (
            np.exp(-eta*est_cumm_losses)/sum(np.exp(-eta*est_cumm_losses))
                )
        arms = range(10)
        prob_rv = scipy.stats.rv_discrete(values=(arms,prob_dist))
        chosen_arm = prob_rv.rvs(size=1)
        loss = envment_obj.generate_bandit_loss(chosen_arm)
        alg_cummloss = alg_cummloss + loss
        est_cumm_losses[chosen_arm] = (est_cumm_losses[chosen_arm] +
            loss/prob_dist[chosen_arm])

    regret = alg_cummloss - envment_obj.get_best_arm_loss()
    return regret

def exp3P_algorithm(envment_obj, eta, beta, gamma):
    #initialization
    alg_cummloss = 0
    est_cumm_gains = np.zeros(10,dtype=np.float128)

    for time in tqdm(range(1, envment_obj.m_total_time+1)):
        envment_obj.m_current_time = time
        prob_dist = (
            (1-gamma)*np.exp(eta*est_cumm_gains)/sum(np.exp(eta*est_cumm_gains))
            + gamma/10
                )
        arms = range(10)
        prob_rv = scipy.stats.rv_discrete(values=(arms, prob_dist))
        chosen_arm = prob_rv.rvs(size=1)
        loss = envment_obj.generate_bandit_loss(chosen_arm)
        alg_cummloss = alg_cummloss + loss
        for idx in range(len(est_cumm_gains)):
            if idx==chosen_arm:
                est_cumm_gains[idx] = est_cumm_gains[idx] + (1 - loss + 
                    beta)/prob_dist[idx]
            else:
                est_cumm_gains[idx] = est_cumm_gains[idx] + beta/prob_dist[idx]

    regret = alg_cummloss - envment_obj.get_best_arm_loss()
    return regret

def exp3IX_algorithm(envment_obj, eta, gamma):
    #initialization
    alg_cummloss = 0
    est_cumm_losses = np.zeros(10,dtype=np.float128)

    for time in tqdm(range(1, envment_obj.m_total_time+1)):
        envment_obj.m_current_time = time
        prob_dist = np.exp(-eta*est_cumm_losses)/sum(np.exp(-eta*est_cumm_losses
            ))
        arms = range(10)
        prob_rv = scipy.stats.rv_discrete(values=(arms,prob_dist))
        chosen_arm = prob_rv.rvs(size=1)
        loss = envment_obj.generate_bandit_loss(chosen_arm)
        alg_cummloss = alg_cummloss + loss
        est_cumm_losses[chosen_arm] = (est_cumm_losses[chosen_arm] +
            loss/(prob_dist[chosen_arm] + gamma))

    regret = alg_cummloss - envment_obj.get_best_arm_loss()
    return regret
      
